#!/bin/bash

python3 - << EOF

import webbrowser

webbrowser.open_new('http://www.hivemq.com/demos/websocket-client/')
webbrowser.open_new('https://docs.google.com/spreadsheets/d/1YK3n43UpGGV05uWk4gs4fGWMt4Gc6fayFX0pglMiE44/edit?usp=sharing')

EOF